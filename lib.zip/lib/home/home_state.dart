enum HomeState {
  success, loading, error, empty
}