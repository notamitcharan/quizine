class SubjectModel {
  String name;
  bool isSelected;

  SubjectModel(this.name, this.isSelected);
}
