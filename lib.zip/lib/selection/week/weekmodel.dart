class WeekModel {
  String name;
  bool isSelected;

  WeekModel(this.name, this.isSelected);
}
